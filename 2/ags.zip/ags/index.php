<?php
session_start();

if (isset($_SESSION['isLogin']) == false) {
    header("Location: login.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticer School</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <div class="form mx-auto border shadow p-5 mt-5" style="background-color: #f1f1f1">
            <h1>AGS Schools</h1>
            <div class="mb-3">
                <a class="btn btn-sm btn-success me-2" href="createForm.php">Insert Student</a>
                <a class="btn btn-sm btn-danger" href="logout.php">Logout</a>
            </div>


            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Roll No.</th>
                        <th scope="col">Name</th>
                        <th scope="col">Class</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">1</th>
                        <td>1</td>
                        <td>Ali</td>
                        <td>Matric</td>
                        <td>
                            <a href="#" class="btn btn-sm btn-warning me-2">Edit</a>
                            <a href="#" class="btn btn-sm btn-danger">Delete</a>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">2</th>
                        <td>2</td>
                        <td>saleem`</td>
                        <td>Matric</td>
                        <td>
                            <a href="#" class="btn btn-sm btn-warning me-2">Edit</a>
                            <a href="#" class="btn btn-sm btn-danger">Delete</a>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">3</th>
                        <td>3</td>
                        <td>Kashif</td>
                        <td>8th</td>
                        <td>
                            <a href="#" class="btn btn-sm btn-warning me-2">Edit</a>
                            <a href="#" class="btn btn-sm btn-danger">Delete</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>


    </div>
</body>

</html>