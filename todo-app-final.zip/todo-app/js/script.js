$(document).ready(function () {


    // add on click functionality on save task button
    $("#saveTask").click(function () {

        let task = $("#taskText").val().trim();

        if (task == '') {
            alert("Input field is required");
            return;
        }

        // append li to ul
        $("#taskList").append(`
        <li class="list-group-item">
            <span class="task-text">${task}</span>
            <button class="btn btn-danger btn-sm delete-btn">delete</button>
        </li>
        `);

        // remove input old text
        $("#taskText").val("")

        // close modal
        $("#taskModal").modal("hide");

    })

    // delete button
    $(document).on("click", ".delete-btn", function () {
        $(this).parent("li").remove();
    })






})