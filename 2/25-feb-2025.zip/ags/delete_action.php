<?php
session_start();

// step 1 = Get id to delete

$id = $_GET['id'];


// step 2 = connect db
$host  = 'localhost';
$user  = "root";
$pwd   = "";
$db    = "agsdb";

$conn = mysqli_connect($host, $user, $pwd, $db);

if (!$conn) {
    die("Database not connected");
}

// step 3 = prepare query
$query = "DELETE FROM `students` WHERE id=$id";


// step 4 = Run query
if (mysqli_query($conn, $query)) {
    // step 5 = redirect to home page
    $_SESSION['deleted'] = "Student successfully deleted";
    
    header("Location: index.php");

} else {
    die("No student found.");
}
