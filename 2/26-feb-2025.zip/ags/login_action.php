<?php
session_start();

// step 1. collect data
$email = $_POST['email'];
$user_pwd   = $_POST['password'];


// step 2. db connect
$host  = 'localhost';
$user  = "root";
$pwd   = "";
$db    = "agsdb";

$conn = mysqli_connect($host, $user, $pwd, $db);

if (!$conn) {
    die("Database not connected");
}

// step 3. select user on basis email and provided password
    $s = "SELECT * FROM users WHERE `email`='$email' AND `password`='$user_pwd' ";
    $result = mysqli_query($conn, $s);


// step 4. if not exist any user with provided email and password, redirct back to login with error
    if (mysqli_num_rows($result) <= 0) {
        $_SESSION['error'] = "Authentication failed, username or password is incorrect";
        header("Location: login.php");
    }


// step 5. if user exist redirect index.php
    $_SESSION['isLogin'] = true;
    header('Location: index.php');
