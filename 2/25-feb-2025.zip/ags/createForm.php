<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap 5 Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2 class="mb-4">Student Registration Form</h2>
    <form method="POST" action="create_action.php">
        <!-- Name Field -->
        <div class="mb-3">
            <label for="name" class="form-label">Full Name</label>
            <input type="text" name="name" class="form-control" id="name" placeholder="Enter your name" required>
        </div>

        <!-- Age Field -->
        <div class="mb-3">
            <label for="age" class="form-label">Age</label>
            <input type="number" name="age" class="form-control" id="age" placeholder="Enter your age" required>
        </div>

        <!-- City Field (Dropdown) -->
        <div class="mb-3">
            <label for="city" class="form-label">City</label>
            <select class="form-select" id="city" name="city" required>
                <option value="" selected disabled>Select your city</option>
                <option value="Lodhran">Lodhran</option>
                <option value="Multan">Multan</option>
                <option value="Karachi">Karachi</option>
                <option value="Bahawalpur">Bahawalpur</option>
            </select>
        </div>

        <!-- Course Field (Dropdown) -->
        <div class="mb-3">
            <label for="course_id" class="form-label">Course</label>
            <select class="form-select" id="course_id" name="course_id" required>
                <option value="" selected disabled>Select your course</option>
                <option value="1">Graphic Designing</option>
                <option value="3">Full Stack Development</option>
                <option value="2">Digital Marketing</option>
                <option value="4">Mobile App Development</option>
            </select>
        </div>

        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
