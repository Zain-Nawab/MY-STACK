<?php


// collect data 

//print_r($_POST);


$name = $_POST['name'];
$age  = $_POST['age'];
$city = $_POST['city'];
$course_id = $_POST['course_id'];


//todo add validation


// connect database
    $host  = 'localhost';
    $user  = "root";
    $pwd   = "";
    $db    = "agsdb";

    $conn = mysqli_connect($host, $user, $pwd, $db);

    if(!$conn) {
        die("Database not connected");
    } 


// run query
    $q = "INSERT INTO `students` (`name`, `age`, `city`, `course_id`) VALUES ('$name', $age, '$city', $course_id)";

    if(mysqli_query($conn, $q)) {
       header("Location: index.php");
    } else {
        echo "error";
        echo mysqli_errno($conn);
    }


// close connection
mysqli_close($conn);


?>