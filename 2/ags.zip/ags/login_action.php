<?php
session_start();

    $savedEmail = "admin@gmail.com";
    $savedPwd   = "123";

    $email = $_POST['email'];
    $pwd   = $_POST['password'];

    if($email != '' && $pwd != '') {
        if($email == $savedEmail && $pwd == $savedPwd) {
            $_SESSION['isLogin'] = true;
            header('Location: index.php');
        } else {
            echo "authenticaiton failed";
        }

    } else {
        echo "email or passsword is missing";
    }


?>